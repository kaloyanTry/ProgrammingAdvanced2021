﻿using System;

namespace DateModifier
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string dateFirst = Console.ReadLine();
            string dateSecond = Console.ReadLine();

            DateModifier dateModifier = new DateModifier(dateFirst, dateSecond);
            Console.WriteLine(dateModifier.GetDateDifference(dateFirst, dateSecond));
        }
    }
}
