﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DateModifier
{
    public class DateModifier
    {
        public DateModifier(string dateFirst, string dateSecond)
        {
            DateFirst = DateTime.ParseExact(dateFirst, "yyyy MM dd", System.Globalization.CultureInfo.InvariantCulture);

            DateSecond = DateTime.ParseExact(dateSecond, "yyyy MM dd", System.Globalization.CultureInfo.InvariantCulture);
        }

        public DateTime DateFirst { get; set; }
        public DateTime DateSecond { get; set; }

        public int GetDateDifference(string dateFirst, string dateSecond)
        {
            return Math.Abs((DateFirst.Date - DateSecond.Date).Days);
        }
    }
}
